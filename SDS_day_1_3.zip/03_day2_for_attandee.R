#### .=========.####
#### | [[ Day 2 ]] ####
#### .=========.####

#### 2. 데이터의 취득과 전처리 ####
#### __ [05] 다양한 함수의 활용 ####
#### _____ ● Pivoting ####
#### _____ ● 데이터 준비 ####
library("reshape2")
set.seed(123)
df = data.frame(Obs = 1:4,
                A = sample(10:99, size = 4),
                B = sample(10:99, size = 4),
                C = sample(10:99, size = 4))
df


#### _____ ● Pivoting - melt() ####
#### _____ ● Pivoting - melt() ####

#### _____ ● Pivoting - cast() ####
#### _____ ● Pivoting - cast() ####

#### _____ ● Pivoting - t() ####

#### _____ ● 반복문 대체 ####

#### _____ ● 반복문 대체 - ifelse() ####
#### _____ ● 반복문 대체 - ifelse() ####
df = data.frame(aa = 1:2, 
                bb = c("a", "b"))
df

#### _____ ● ifelse() 예제 ####
# ▶ rating_ramyun.csv 데이터를 불러와 df 객체로 저장
# ▶ ifelse() 함수를 활용하여 “kr”이라는 변수를 df 객체에 새로 생성
# ▶ “kr” 변수에는 Country 변수값이 남한(South Korea)인 경우 1을, 그 이외의 값일 경우 0이 기록되도록 하시오.


#### _____ ● 반복문 대체 - apply() ####
#### _____ ● 반복문 대체 - apply() ####
# 데이터 준비 
data("iris")
df = head(iris[, 1:4])
df

#### _____ ● apply() 예제 ####
# ▶ apply() 함수를 활용하여 class_score.csv의 학생 시험성적 평균점수를 구하시오.
# ▶ 과목별 평균점수, 최고점, 최저점을 구해서 df_subject 라는 데이터프레임 객체에 정리하시오.


#### _____ ● 반복문 대체 - sapply() ####
#### _____ ● 반복문 대체 - sapply() ####

#### _____ ● Join ####
# Left Join

# Inner Join

#### _____ ● 데이터 준비 ####
source("data_generator_join.R", encoding = "UTF-8")

#### _____ ● Join - 내장 함수 ####
# Left Join

# Inner Join


#### _____ ● Join - SQL 문법 ####
library("sqldf")

# Left Join

# Inner Join


#### _____ ● Join - dplyr 패키지 ####
library("dplyr")

# Left Join

# Inner Join

#### _____ ● dplyr 패키지 ####
# filter() - 조건 기반 행추출
# summerize() - 각 변수의 요약정보 생산
# group_by() - 행 그룹화
# mutate() - 기존 변수를 기반으로 새로운 변수 생산
# arrange() - 하나 또는 그 이상의 변수 정렬
# join() - "키"변수를 기준으로 두 데이터 세트 병합


#### _____ ● magrittr 패키지 ####

#### _____ ● 파이프 연산자 실습 ####
library("magrittr")
text = "asdf1234!@#$"

#### 3. 데이터 시각화 ####
#### __ [01] 고급 그래프 ####
#### _____ ● 반응형 그래프 ####
library("ggplot2")
library("plotly")

gg = ggplot() + 
  geom_point(aes(x = 1:10,
                 y = 1:10),
             size = 10)
ggplotly(gg)

#### _____ ● 반응형 3D 그래프 ####
library("reshape2")
library("plotly")

x = seq(from = -4 * pi, to = 4 * pi, length.out = 100)
df = expand.grid(x = x, y = x)
df$r = sqrt(df$x^2 + df$y^2)
df$z = cos(df$r^2) * exp(-df$r/6)

data_z = acast(df, x ~ y, value.var = "z")
plot_ly(z = data_z, type = "surface")

#### _____ ● 반응형 네트워크 그래프 ####
library("networkD3")

src = c(rep("A",4), rep("B", 2), rep("C", 2), "D")
target = c("B", "C", "D", "J", "E", "F", "G", "H", "I")
networkData = data.frame(src, target)

simpleNetwork(networkData)

#### _____ ● 제품 및 브랜드 평가 ####
library("dplyr")
library("tidyr")
library("ggplot2")

df = read.csv("prods_scores.csv", stringsAsFactors = FALSE)
df[, "score_phrase"] = factor(df$score_phrase,
                              levels = c("Disaster", "Unbearable", "Painful", "Awful", "Bad",
                                         "Mediocre",
                                         "Okay", "Good", "Great", "Amazing", "Masterpiece"))

Microsoft = paste0("Xbox", c(" One", "", " 360"))
Sony = paste0("PlayStation", c(" Portable", " 4", " 2", " 3", " Vita", ""))
PC = c("Linux", "Macintosh", "SteamOS", "PC")
Nintendo = c(paste0("Nintendo ", c("3DS", 64, "64DD", "DS", "DSi")),
             "New Nintendo 3DS",
             paste0("Game Boy", c("", " Color", " Advance")),
             "Wii",
             "Wii U",
             "NES",
             "GameCube",
             "Super NES")

df[, "company"] = ifelse(df$platform %in% Microsoft, "Microsoft",
                         ifelse(df$platform %in% Sony, "Sony",
                                ifelse(df$platform %in% PC, "PC",
                                       ifelse(df$platform %in% Nintendo,
                                              "Nintendo", "Other"))))

my.palette = c("Sony"      = "#EDC951",
               "Nintendo"  = "#EB6841",
               "PC"        = "#CC2A36",
               "Microsoft" = "#4F372D",
               "Other"     = "#00A0B0")

ggplot(data = df, 
       aes(x = score_phrase,
           y = company,
           color = company)) +
  # geom_point() +
  geom_jitter(alpha = 0.2) +
  scale_color_manual(values = my.palette) +
  labs(x = "Score category", y = NULL, title = "Reviews by Score categories") +
  theme_bw() +
  theme(legend.position = "none")

#### _____ ● Nebraska 지역 기온 시각화 ####
library("lubridate")
library("viridis")
library("ggridges")

df_weather = read.csv("nebraska_2016.csv", stringsAsFactors = FALSE)
df_weather[, "Month"] = month(df_weather$CST)
df_weather[, "Month_order"] = factor(month.name[df_weather$Month],
                                     levels = month.name)

ggplot(df_weather, 
       aes(x = Mean.TemperatureF, 
           y = Month_order, 
           fill = ..x..)) +
  geom_density_ridges_gradient(scale = 3, 
                               rel_min_height = 0.01, 
                               gradient_lwd = 1) +
  scale_x_continuous(expand = c(0.01, 0.01)) +
  scale_y_discrete(  expand = c(0.01, 0.01)) +
  scale_fill_viridis(name = "Temp. [F]", option = "C") +
  labs(title = 'Temperatures in Lincoln NE') +
  theme_ridges(font_size = 13, grid = TRUE) + 
  theme(axis.title.y = element_blank())


#### __ [02] 유용한 사이트 ####
# http://ggplot2.tidyverse.org/reference
# https://www.rstudio.com/resources/cheatsheets
# https://color.adobe.com
# http://www.color-hex.com/

#### __ [03] ggplot2 시작하기 #####
#### _____ ● 산점도 ####
# 데이터 & 패키지 준비
data_point = data.frame(xx = 1:10,
                        yy = sample(1:10, 10))
library("ggplot2")

# 그래프
ggplot(data = data_point, aes(x = xx, y = yy)) + geom_point()
ggplot(data = data_point, aes(xx, yy)) + geom_point()

#### _____ ● 기초 문법 ####
# 스타일 1

# 스타일 2

#### __ [04] 기본 그래프 ####
#### _____ ● 선 그래프 ####

#### _____ ● 막대 그래프 ####
data_bar = data.frame(xx = 1:10,
                      yy = sample(1:3, 10, replace = TRUE))
data_bar

#### _____ ● 추가 기능####


#### __ [05] 다중 그래프 ####
#### _____ ● 선 그래프 ####
# 데이터 준비
line_df = data.frame(obs = 1:30,
                     var_1 = rep(c("A", "B", "C"), 10),
                     value = sample(1:100, size = 10),
                     stringsAsFactors = FALSE)
head(line_df)

library("ggplot2")

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4

# 그래프 5

# 그래프 5 - 퀴즈: 코드를 조금 더 간결하게 바꾸시오.
# style 1

# style 2


#### __ [06] 색상 설정 ####
#### _____ ● 막대 그래프 ####
# 데이터 준비
bar_df = data.frame(obs = 1:10,
                    var = rep(c("A", "B", "C"), length.out = 10),
                    value = sample(1:100, size = 10),
                    stringsAsFactors = FALSE)
head(bar_df)

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4

# 그래프 5

# 그래프 5 - 퀴즈: 그래프 4와 5의 차이점은?

# 그래프 6

# 그래프 7


#### _____ ● 막대 그래프 ####
# 데이터 준비
color_df = data.frame(obs = 1:10,
                      var = rep(c("A", "B", "C"), length.out = 10),
                      value = sample(1:100, size = 10),
                      stringsAsFactors = FALSE)
head(color_df)

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4

# 그래프 5


#### _____ ● 선 그래프 ####
# 데이터 준비
color_df = data.frame(obs = 1:10,
                      var = rep(c("A", "B", "C"), length.out = 10),
                      value = sample(1:100, size = 10),
                      stringsAsFactors = FALSE)
head(color_df)

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4

# 그래프 5

# 그래프 6


#### _____ ● 선 그래프 - 색상 함수 활용 ####
# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4

# 그래프 5 - 중요!


#### __ [07] 축 설정 ####
#### _____ ● 여백 조정 ####
# 데이터 준비
bar_df = data.frame(obs = 1:10,
                    var = rep(c("A", "B", "C"), length.out = 10),
                    value = sample(1:100, size = 10),
                    stringsAsFactors = FALSE)
head(bar_df)

# 기본 그래프
ggplot(data = bar_df, aes(x = var,
                          y = value,
                          fill = value)) + 
  # geom_col()
  geom_bar(stat = "identity")

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4


#### _____ ● 최대, 최소값 설정 ####
# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4


#### _____ ● 구간 설정 ####
# 그래프 1


# 그래프 2


#### __ [08] 요소(element) 설정 ####
#### _____ ● 기호 변경 ####
# 데이터 준비
bar_df = data.frame(obs = 1:10,
                    var = rep(c("A", "B", "C"), length.out = 10),
                    value = sample(1:100, size = 10),
                    stringsAsFactors = FALSE)
head(bar_df)

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4


#### _____ ● 기호 모음 ####


#### _____ ● 글자 모양 설정 ####
# 기본 그래프

# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4


#### _____ ● 제목 변경 ####
# 그래프 1

# 그래프 2

# 그래프 3

# 그래프 4


#### __ [10] 덧그리기 ####
#### _____ ● 가로/세로선 추가 ####
# 데이터 준비
bar_df = data.frame(obs = 1:10,
                    var = rep(c("A", "B", "C"), length.out = 10),
                    value = sample(1:100, size = 10),
                    stringsAsFactors = FALSE)
head(bar_df)

# 기본 그래프

# 그래프(가로선 추가)


# 그래프(세로선 추가)

# Q. geom_vline() 함수 하나로 
#    위 코드의 결과와 같은 것을 구현하시오.


#### _____ ● annotate() 함수 ####
# 텍스트

# 사각형

# 선분

# 값 범위

#### __ [11] 범례 ####
#### _____ ● 사전 준비 ####
# 데이터 준비
bar_df = data.frame(obs = 1:10,
                    var = rep(c("A", "B", "C"), length.out = 10),
                    value = sample(1:100, size = 10),
                    stringsAsFactors = FALSE)
head(bar_df)

# 기본 그래프

#### _____ ● 위치 조정 ####
# top, bottom, left, right
# 그래프 1

# 그래프 2

#### _____ ● 텍스트 ####
# 그래프 3

# 그래프 4

#### _____ ● 기타 ####
# 그래프 5

# 그래프 6


#### __ [12] 다양한 그래프 ####
#### _____ ● 히스토그램 ####
# 데이터 준비
data("diamonds")

# 그래프

# 그래프 퀴즈: Very Good 이상 등급만 사용하여 그리시오.

#### _____ ● Dot plot ####
# 데이터 준비
data("mtcars")

# dot plot
ggplot(mtcars, aes(x = mpg)) +
  geom_dotplot(binwidth = 1.5)


#### _____ ● Ribbon + Line ####
# 데이터 준비
data("LakeHuron")
huron = data.frame(year  = 1875:1972,
                   level = as.vector(LakeHuron))

# ribbon graph


#### _____ ● 다차원 시각화 ####
library("ggplot2")
data("mtcars")


#### _____ ● 분할 ####
library("ggplot2")
data("diamonds")


#### _____ ● 병합 ####
library("ggExtra")
library("ggplot2")
set.seed(1234)
df = data.frame(x = c(rnorm(500, mean = -1), rnorm(500, mean = 1.5)),
                y = c(rnorm(500, mean = -1), rnorm(500, mean = 1.7)))


#### _____ ● 흐름도 ####
library("ggparallel")
library("ggplot2")

#### _____ ● 막대그래프 중첩 ####


#### 4. 통계 ####

#### __ [01] 들어가며 ####

#### _____ ● 개요 ####

#### _____ ● 표본 ####

#### _____ ● 사건 ####

#### _____ ● 확률 ####


#### __ [02] 통계량 ####
#### _____ ● 통계량의 정의 ####

#### _____ ● 평균 - mean() ####
# 산술 평균

# 기하 평균

# 결측치가 포함되어 있는 값의 평균 계산

# na.rm 파라미터 추가

# 글자가 포함되어 있는 값의 평균 계산

# na.rm 파라미터 추가

#### _____ ● 중앙값 - median() ####

#### _____ ● 최빈값 ####
mode = function(x){
  ux = unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

mode(c(1, 1, 1, 2, 3, 4, 4))

#### _____ ● 분산과 표준편차 - var(), sd() ####

#### _____ ● 통계량의 함정 ####
# https://github.com/stephlocke/datasauRus

library("ggplot2")
library("datasauRus")

#### __ [03] 가설검정 Ⅰ ####
#### _____ ● 용어 정리 ####
# ▶ 가설 검정: 모집단의 특성에 대한 특정 가설 설정 후 표본을 관찰하여 해당 가설의 채택 여부를 결정하는 방법
# ▶ 귀무가설(영가설, Null Hypothesis, 𝐻_0): 기존에 알려진 사실
# ▶ 대립가설(연구가설, Alternative Hypothesis, 𝐻_1): 연구를 통해 밝히고자 하는 가설
# ▶ 유의 수준(𝛼): 제 1종 오류를 범할 확률의 최대 허용치
# ▶ p-value: 귀무가설이 맞다는 전제 하에, 관측된 통계값 혹은 그 값보다 큰 값이 나올 확률


#### _____ ● 가설 검정 절차 ####

#### _____ ● 분할표와 오류 ####
#### _____ ● 분할표 해석 ####
# 정확도

# 정밀도

# 재현률

#### _____ ● 분할표 ####
set.seed(1234)


#### __ [04] 추론 통계 ####
#### _____ ● 개념 ####

#### _____ ● 용어 정리 ####
# ▶ 추정(estimation): 표본을 통해 모집단 특성을 추측하는 과정
# ▶ 가설검정(hypothesis): 모집단 실제값과 표본값을 이용하여 가설의 옳고 그름을 판정하는 과정
# ▶ 귀무가설(null hypothesis): 연구에서 검증하는 가설
# ▶ 대립가설(alternative hypothesis): 연구자가 연구를 통해 입증되기를 기대하는 가설(귀무가설과 반대)
# ▶ 모수적 방법(parametric method): 모집단의 특정 확률 분포를 가정하고, 해당 표본 분포의 평균과 분산을 추정
# ▶ 비모수적 방법(non-parametric method): 표본의 반복적인 복원 추출로 표본 분포를 생성하고 모집단의 분포를 추정


#### _____ ● 점 추정 ####

#### _____ ● 용어 정리 ####
# ▶ 점 추정치(point estimate): 하나의 수치에 의해 추정된 모집단의 특성
# ▶ 추정량(estimator): 모집단 특성을 추정하기 위하여 이용되는 통계량
# ▶ 추정치(estimate): 추정량을 통하여 계산된 구체적인 수치


#### _____ ● 예제 코드 ####
library("MASS")

#### _____ ● 좋은 점 추정량의 조건
# 불편성 

# 효율성

# 일치성

# 충분성


#### _____ ● 구간 추정 #### 
#### _____ ● 용어 정리 - 국간 추정 ####
# ▶ 유의 수준(Significance level): 통계적 검정(檢定)에서 가설을 기각(棄却)할 때, 그 가설이 옳은데도 불구하고 틀린 것으로 치고 기각하는 확률의 허용 수준(1종 오류의 최대값)
# ▶ 신뢰 구간(confidence interval): 지정된 신뢰수준을 통해 계산된 구간


#### _____ ● 정규분포 신뢰구간 관련 코드 1 ####
library("ggplot2")

nums = seq(-4, 4, length = 100)

ggplot() + 
  geom_line(aes(x = nums, y = dnorm(nums)), size = 2) + 
  geom_vline(xintercept = c(mean(nums),
                            mean(nums) - 1.96,
                            mean(nums) + 1.96), 
             color = "#FF0000", linetype = 2) + 
  geom_vline(xintercept = c(mean(nums), mean(nums) - 2.33, mean(nums) + 2.33),
             color = "#009900", linetype = 2) + 
  geom_vline(xintercept = c(mean(nums), mean(nums) - 2.58, mean(nums) + 2.58),
             color = "#0000FF", linetype = 2)


#### _____ ● 정규분포 신뢰구간 관련 코드 2 ####


#### _____ ● 모평균의 신뢰 구간 ####
# (모표준편차를 모르는 경우)
set.seed(123)
x = sample(30:70, size = 15)

#### _____ ● 모비율의 신뢰 구간 ####
# (모표준편차를 모르는 경우)


#### __ [05] 표본 ####
#### _____ ● 표본 추출의 정의 ####

#### _____ ● 표본 추출의 종류 ####


#### _____ ● 확률적 표본 추출의 정의 ####

#### _____ ● 단순 임의 추출의 정의 ####

#### _____ ● 단순 임의 추출의 특징 ####

#### _____ ● 단순 임의 추출 ####
# 복원 추출

# 비복원 추출

#### _____ ● 군집 표본추출의 정의 ####

#### _____ ● 군집 표본추출의 특징 ####

#### _____ ● 예시 ####
# 행정구역 기준 표본 추출

# 교육기관 기준 표본 추출


#### _____ ● 체계적 표본 추출의 정의 ####

#### _____ ● 체계적 표본 추출의 특징 ####

#### _____ ● 예시 ####
